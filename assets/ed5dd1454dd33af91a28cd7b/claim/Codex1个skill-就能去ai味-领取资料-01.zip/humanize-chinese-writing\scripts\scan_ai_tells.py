#!/usr/bin/env python3
"""Heuristic scanner for formulaic Chinese prose; not an AI detector."""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path


PHRASES = {
    "meta": [
        "值得注意的是", "不可忽视的是", "毋庸置疑", "显而易见", "综上所述",
        "总的来说", "由此可见", "从某种意义上说", "在当今", "随着.*?不断发展",
    ],
    "transitions": [
        "首先", "其次", "再次", "最后", "此外", "与此同时", "另一方面",
        "因此", "从而", "进而",
    ],
    "buzzwords": [
        "赋能", "打造", "重塑", "引领", "驱动", "沉淀", "抓手", "闭环",
        "全方位", "多维度", "深层次", "颠覆性", "革命性", "无限可能",
        "全新篇章", "质的飞跃",
    ],
    "emotion": [
        "心中涌起", "内心深处", "仿佛在诉说", "令人不禁", "让我们一起",
        "相信你也", "你是否曾经", "想象一下",
    ],
}

STRUCTURES = {
    "not_a_but_b": re.compile(r"不是.{1,40}?[，,]?(?:而是|只是)"),
    "not_only_but": re.compile(r"不仅.{1,60}?(?:更|还|而且)"),
    "summary_close": re.compile(r"(?:这意味着|这表明|由此可见|综上所述)"),
}

SENTENCE_SPLIT = re.compile(r"(?<=[。！？!?])")


def read_text(path: str | None) -> str:
    if path:
        return Path(path).read_text(encoding="utf-8")
    return sys.stdin.read()


def locations(text: str, pattern: str) -> list[dict[str, object]]:
    rx = re.compile(pattern)
    hits = []
    for match in rx.finditer(text):
        line = text.count("\n", 0, match.start()) + 1
        hits.append({"text": match.group(0), "line": line})
    return hits


def analyze(text: str) -> dict[str, object]:
    compact = re.sub(r"\s+", "", text)
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    sentences = [s.strip() for s in SENTENCE_SPLIT.split(text) if s.strip()]
    sentence_lengths = [len(re.sub(r"\s+", "", s)) for s in sentences]

    phrase_hits: dict[str, list[dict[str, object]]] = {}
    phrase_count = 0
    for category, patterns in PHRASES.items():
        found = []
        for pattern in patterns:
            found.extend(locations(text, pattern))
        phrase_hits[category] = found
        phrase_count += len(found)

    structure_hits = {
        name: [
            {"text": m.group(0), "line": text.count("\n", 0, m.start()) + 1}
            for m in rx.finditer(text)
        ]
        for name, rx in STRUCTURES.items()
    }

    punctuation = Counter(ch for ch in text if ch in "：:———“”\"（）()；;")
    avg_sentence = sum(sentence_lengths) / len(sentence_lengths) if sentence_lengths else 0
    spread = (
        sum((length - avg_sentence) ** 2 for length in sentence_lengths) / len(sentence_lengths)
    ) ** 0.5 if sentence_lengths else 0
    avg_para_sentences = len(sentences) / len(paragraphs) if paragraphs else 0
    density = phrase_count * 1000 / len(compact) if compact else 0

    severity = "light"
    structure_count = sum(len(items) for items in structure_hits.values())
    if density > 15 or structure_count >= 5 or avg_para_sentences > 5:
        severity = "heavy"
    elif density > 5 or structure_count >= 3 or avg_para_sentences >= 3:
        severity = "medium"

    notes = []
    if len(sentence_lengths) >= 4 and spread < 6:
        notes.append("句长变化较小，检查是否存在机械节奏。")
    if phrase_count:
        notes.append("高频表达需结合上下文判断，不要机械替换。")
    if punctuation.get("：", 0) + punctuation.get(":", 0) >= 4:
        notes.append("冒号较多，检查是否在用标点代替自然衔接。")

    return {
        "disclaimer": "这是编辑启发式扫描，不是 AI 作者检测。",
        "characters": len(compact),
        "paragraphs": len(paragraphs),
        "sentences": len(sentences),
        "average_sentence_length": round(avg_sentence, 2),
        "sentence_length_stddev": round(spread, 2),
        "average_sentences_per_paragraph": round(avg_para_sentences, 2),
        "formulaic_phrase_density_per_1000_chars": round(density, 2),
        "suggested_editing_intensity": severity,
        "phrase_hits": phrase_hits,
        "structure_hits": structure_hits,
        "punctuation_counts": dict(punctuation),
        "notes": notes,
    }


def render_text(report: dict[str, object]) -> str:
    lines = [
        str(report["disclaimer"]),
        f"字符/段落/句子：{report['characters']} / {report['paragraphs']} / {report['sentences']}",
        f"平均句长：{report['average_sentence_length']}；句长标准差：{report['sentence_length_stddev']}",
        f"平均每段句数：{report['average_sentences_per_paragraph']}",
        f"套话密度（每千字）：{report['formulaic_phrase_density_per_1000_chars']}",
        f"建议处理强度：{report['suggested_editing_intensity']}",
    ]
    for category, items in report["phrase_hits"].items():
        if items:
            sample = "、".join(f"{x['text']}@L{x['line']}" for x in items[:8])
            lines.append(f"{category}: {sample}")
    for category, items in report["structure_hits"].items():
        if items:
            sample = "、".join(f"{x['text']}@L{x['line']}" for x in items[:8])
            lines.append(f"{category}: {sample}")
    lines.extend(f"提示：{note}" for note in report["notes"])
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", nargs="?", help="UTF-8 text file; omit to read stdin")
    parser.add_argument("--json", action="store_true", help="emit JSON")
    args = parser.parse_args()
    try:
        report = analyze(read_text(args.path))
    except (OSError, UnicodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(render_text(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
